const yo = [
  "Pablo Baleztena",
  "Programar",
  "La Plata, Buenos Aires, Argentina",
];

module.exports = yo;
