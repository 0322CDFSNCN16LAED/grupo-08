//requires
const banana = require("./operaciones");

//ejecuciones
console.log(banana.sumatoria(1, 2));
