const controller = {
    index: (req, res) => {
        // Do the magic
    },
    search: (req, res) => {
        // Do the magic
    },
};

module.exports = controller;
